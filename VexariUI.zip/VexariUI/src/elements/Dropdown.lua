local cloneref = (cloneref or clonereference or function(instance)
	return instance
end)

local UserInputService = cloneref(game:GetService("UserInputService"))
local Mouse = cloneref(game:GetService("Players")).LocalPlayer:GetMouse()
local Camera = cloneref(game:GetService("Workspace")).CurrentCamera

local Creator = require("../modules/Creator")
local New = Creator.New
local Tween = Creator.Tween

local CreateLabel = require("../components/ui/Label").New
local CreateInput = require("../components/ui/Input").New
local CreateDropdown = require("../components/ui/Dropdown").New

local CurrentCamera = workspace.CurrentCamera

local Element = {
	UICorner = 10,
	UIPadding = 12,
	MenuCorner = 15,
	MenuPadding = 5,
	TabPadding = 10,
	SearchBarHeight = 39,
	TabIcon = 18,
}

function Element:New(Config)
	local Dropdown = {
		__type = "Dropdown",
		Title = Config.Title or "Dropdown",
		Desc = Config.Desc or nil,
		Locked = Config.Locked or false,
		LockedTitle = Config.LockedTitle,
		Values = Config.Values or {},
		MenuWidth = Config.MenuWidth or 180,
		Value = Config.Value,
		AllowNone = Config.AllowNone,
		SearchBarEnabled = Config.SearchBarEnabled or false,
		Multi = Config.Multi,
		Callback = Config.Callback or nil,

		UIElements = {},

		Opened = false,
		Tabs = {},

		Width = 150,
	}

	if Dropdown.Multi and not Dropdown.Value then
		Dropdown.Value = {}
	end
	if Dropdown.Values and typeof(Dropdown.Value) == "number" then
		Dropdown.Value = Dropdown.Values[Dropdown.Value]
	end

	Dropdown.DropdownFrame = require("../components/window/Element")({
		Title = Dropdown.Title,
		Desc = Dropdown.Desc,
		Parent = Config.Parent,
		TextOffset = Dropdown.Callback and Dropdown.Width or 20,
		Hover = not Dropdown.Callback and true or false,
		Tab = Config.Tab,
		Index = Config.Index,
		Window = Config.Window,
		ElementTable = Dropdown,
		ParentConfig = Config,
		Tags = Config.Tags,
	})

	if Dropdown.Callback then
		Dropdown.UIElements.Dropdown =
			CreateLabel("", nil, Dropdown.DropdownFrame.UIElements.Main, nil, Config.Window.NewElements and 12 or 10)

		Dropdown.UIElements.Dropdown.Frame.Frame.TextLabel.TextTruncate = "AtEnd"
		Dropdown.UIElements.Dropdown.Frame.Frame.TextLabel.Size =
			UDim2.new(1, Dropdown.UIElements.Dropdown.Frame.Frame.TextLabel.Size.X.Offset - 18 - 12 - 12, 0, 0)

		Dropdown.UIElements.Dropdown.Size = UDim2.new(0, Dropdown.Width, 0, 36)
		Dropdown.UIElements.Dropdown.Position = UDim2.new(1, 0, Config.Window.NewElements and 0 or 0.5, 0)
		Dropdown.UIElements.Dropdown.AnchorPoint = Vector2.new(1, Config.Window.NewElements and 0 or 0.5)

		-- New("UIScale", {
		--     Parent = Dropdown.UIElements.Dropdown,
		--     Scale = .85,
		-- })
	end

	Dropdown.DropdownMenu = CreateDropdown(Config, Dropdown, Element, "Dropdown")

	Dropdown.Display = Dropdown.DropdownMenu.Display
	Dropdown.Refresh = Dropdown.DropdownMenu.Refresh
	Dropdown.Select = Dropdown.DropdownMenu.Select
	Dropdown.Open = Dropdown.DropdownMenu.Open
	Dropdown.Close = Dropdown.DropdownMenu.Close

	local DropdownIconData = Creator.Icon("chevrons-up-down")
	local DropdownIcon = New("ImageLabel", {
		Image = DropdownIconData and DropdownIconData[1],
		ImageRectOffset = DropdownIconData and DropdownIconData[2] and DropdownIconData[2].ImageRectPosition,
		ImageRectSize = DropdownIconData and DropdownIconData[2] and DropdownIconData[2].ImageRectSize,
		Size = UDim2.new(0, 18, 0, 18),
		Position = UDim2.new(1, Dropdown.UIElements.Dropdown and -12 or 0, 0.5, 0),
		ThemeTag = {
			ImageColor3 = "Icon",
		},
		AnchorPoint = Vector2.new(1, 0.5),
		Parent = Dropdown.UIElements.Dropdown and Dropdown.UIElements.Dropdown.Frame
			or Dropdown.DropdownFrame.UIElements.Main,
	})

	function Dropdown:Lock()
		Dropdown.Locked = true
		if Dropdown.Opened or Dropdown.UIElements.MenuCanvas.Visible then
			Dropdown:Close()
		end
		return Dropdown.DropdownFrame:Lock(Dropdown.LockedTitle)
	end
	function Dropdown:Unlock()
		Dropdown.Locked = false
		return Dropdown.DropdownFrame:Unlock()
	end

	if Dropdown.Locked then
		Dropdown:Lock()
	end

	return Dropdown.__type, Dropdown
end

return Element
