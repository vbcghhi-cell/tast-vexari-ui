--[[
    Vexari UI Example

    example moved to main.client.lua
]]


loadstring(game:HttpGet('https://raw.githubusercontent.com/vbcghhi-cell/WindUI/refs/heads/main/main.client.lua'))()
