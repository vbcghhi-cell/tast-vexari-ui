-- Moved to main_example.lua

loadstring(game:HttpGet("https://raw.githubusercontent.com/vbcghhi-cell/WindUI/refs/heads/main/main_example.lua"))()